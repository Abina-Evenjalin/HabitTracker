package com.example.habittrack;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import androidx.core.app.NotificationCompat;

public class AlarmReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        // Create and show the notification
        showNotification(context);
    }

    // Method to show the notification
    private void showNotification(Context context) {
        // Create an intent to open the app when the notification is tapped
        Intent notificationIntent = new Intent(context, MainActivity.class);
        notificationIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, "habitReminder")
                .setSmallIcon(R.drawable.baseline_access_alarm_24) // Make sure you have an appropriate icon
                .setContentTitle("Habit Tracker Reminder")
                .setContentText("Don't forget to check your habit list for the day!")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent) // Set the intent for notification tap
                .setAutoCancel(true); // Dismiss the notification when tapped

        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (notificationManager != null) {
            notificationManager.notify(100, builder.build());
        }
    }
}
