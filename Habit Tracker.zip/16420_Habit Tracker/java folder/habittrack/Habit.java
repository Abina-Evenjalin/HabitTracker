package com.example.habittrack;

import java.util.Map;

public class Habit {

    private String name;
    private Map<String, Boolean> dailyStatus; // Date as key, followed status as value

    // Constructor
    public Habit(String name, Map<String, Boolean> dailyStatus) {
        this.name = name;
        this.dailyStatus = dailyStatus;
    }

    // Getters and setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Map<String, Boolean> getDailyStatus() {
        return dailyStatus;
    }

    public void setDailyStatus(Map<String, Boolean> dailyStatus) {
        this.dailyStatus = dailyStatus;
    }
}