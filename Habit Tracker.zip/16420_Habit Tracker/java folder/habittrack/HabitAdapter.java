package com.example.habittrack;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Canvas;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HabitAdapter extends RecyclerView.Adapter<HabitAdapter.HabitViewHolder> {

    private List<Habit> habits;
    private Context context;

    public HabitAdapter(List<Habit> habits, Context context) {
        this.habits = habits;
        this.context = context;
    }

    @NonNull
    @Override
    public HabitViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_habit, parent, false);
        return new HabitViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HabitViewHolder holder, int position) {
        Habit habit = habits.get(position);
        holder.habitName.setText(habit.getName());

        // Clear previous checkboxes
        holder.dailyCheckboxesContainer.removeAllViews();

        // Add CheckBoxes dynamically for each day of the month
        for (int i = 1; i <= 31; i++) {
            CheckBox checkBox = new CheckBox(context);
            checkBox.setText(String.valueOf(i));
            checkBox.setId(View.generateViewId());
            holder.dailyCheckboxesContainer.addView(checkBox);

            // Set the checkbox state based on habit data
            boolean isChecked = habit.getDailyStatus().getOrDefault(String.valueOf(i), false);
            checkBox.setChecked(isChecked);

            final int day = i;
            checkBox.setOnClickListener(v -> {
                boolean isChecked1 = checkBox.isChecked();
                habit.getDailyStatus().put(String.valueOf(day), isChecked1);
            });
        }
    }

    @Override
    public int getItemCount() {
        return habits.size();
    }

    public void removeHabit(int position) {
        if (position >= 0 && position < habits.size()) {
            habits.remove(position);
            notifyItemRemoved(position);
        }
    }

    public void updateHabit(int position, String newHabitName) {
        if (position >= 0 && position < habits.size()) {
            Habit habit = habits.get(position);
            habit.setName(newHabitName);
            notifyItemChanged(position);
        }
    }

    public ItemTouchHelper.SimpleCallback getItemTouchHelperCallback() {
        return new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {

            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                int position = viewHolder.getAdapterPosition();
                if (direction == ItemTouchHelper.LEFT) {
                    showDeleteDialog(position);
                } else if (direction == ItemTouchHelper.RIGHT) {
                    showEditDialog(position);
                }
            }

            @Override
            public void onChildDraw(Canvas c, @NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, float dX, float dY, int actionState, boolean isCurrentlyActive) {
                super.onChildDraw(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive);
            }
        };
    }

    private void showDeleteDialog(int position) {
        new AlertDialog.Builder(context)
                .setTitle("Delete Habit")
                .setMessage("Are you sure you want to delete this habit?")
                .setPositiveButton("Delete", (dialog, which) -> removeHabit(position))
                .setNegativeButton("Cancel", (dialog, which) -> notifyItemChanged(position))
                .show();
    }

    private void showEditDialog(int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Edit Habit");

        LayoutInflater inflater = LayoutInflater.from(context);
        View dialogView = inflater.inflate(R.layout.dialog_edit_habit, null);
        final EditText input = dialogView.findViewById(R.id.habit_input);
        input.setText(habits.get(position).getName());
        builder.setView(dialogView);

        builder.setPositiveButton("Save", (dialog, which) -> {
            String newHabitName = input.getText().toString();
            updateHabit(position, newHabitName);
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

        builder.show();
    }

    public static class HabitViewHolder extends RecyclerView.ViewHolder {
        TextView habitName;
        LinearLayout dailyCheckboxesContainer;

        HabitViewHolder(View itemView) {
            super(itemView);
            habitName = itemView.findViewById(R.id.habit_name);
            dailyCheckboxesContainer = itemView.findViewById(R.id.daily_checkboxes_container);
        }
    }
}
