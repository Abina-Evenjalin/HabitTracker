package com.example.habittrack;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HabitListActivity extends AppCompatActivity {

    private RecyclerView habitRecyclerView;
    private HabitAdapter habitAdapter;
    private List<Habit> habitList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_habit_list);

        habitRecyclerView = findViewById(R.id.habit_recycler_view);
        FloatingActionButton addHabitFab = findViewById(R.id.add_habit_fab);

        habitList = new ArrayList<>();
        habitAdapter = new HabitAdapter(habitList, this); // Pass context here
        habitRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        habitRecyclerView.setAdapter(habitAdapter);

        // Add swipe functionality
        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(habitAdapter.getItemTouchHelperCallback());
        itemTouchHelper.attachToRecyclerView(habitRecyclerView);

        addHabitFab.setOnClickListener(v -> showAddHabitDialog());
    }

    private void showAddHabitDialog() {
        // Inflate the dialog layout
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_add_habit, null);
        final EditText habitInput = dialogView.findViewById(R.id.habit_input);

        // Create and show the dialog
        new AlertDialog.Builder(this)
                .setTitle("Add New Habit")
                .setView(dialogView)
                .setPositiveButton("Save", (dialog, which) -> {
                    String newHabitName = habitInput.getText().toString();
                    if (!newHabitName.isEmpty()) {
                        // Create a new Habit with an empty daily status map
                        Habit newHabit = new Habit(newHabitName, new HashMap<>());
                        habitList.add(newHabit);
                        habitAdapter.notifyItemInserted(habitList.size() - 1);
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_history) {
            Intent intent = new Intent(this, HistoryActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
