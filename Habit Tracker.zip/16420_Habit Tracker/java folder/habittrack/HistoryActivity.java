package com.example.habittrack;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.HashMap;
import java.util.Map;

public class HistoryActivity extends AppCompatActivity {

    private TextView analysisTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        // Initialize UI components
        analysisTextView = findViewById(R.id.analysisTextView);

        // Fetch and analyze habit data
        Habit habit = fetchHabitData();
        String analysis = analyzeHabit(habit);

        // Display the analysis
        analysisTextView.setText(analysis);
    }

    // Method to fetch habit data (dummy implementation)
    private Habit fetchHabitData() {
        // Initialize dummy data
        Map<String, Boolean> dailyStatus = new HashMap<>();
        dailyStatus.put("2024-08-25", true);
        dailyStatus.put("2024-08-26", false);
        // Add more dummy data as needed

        // Create and return a Habit instance
        return new Habit("Drink Water", dailyStatus);
    }

    // Method to analyze habit data
    private String analyzeHabit(Habit habit) {
        if (habit == null || habit.getDailyStatus().isEmpty()) {
            return "No habit data available.";
        }

        int totalDays = habit.getDailyStatus().size();
        int followedDays = 0;

        for (Boolean status : habit.getDailyStatus().values()) {
            if (status) {
                followedDays++;
            }
        }

        double followPercentage = (double) followedDays / totalDays * 100;

        return String.format("Habit: %s\nFollowed Days: %d/%d (%.2f%%)",
                habit.getName(), followedDays, totalDays, followPercentage);
    }
}